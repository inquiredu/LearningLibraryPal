/**
 * shared/utils/mail.ts
 * Reusable MailApp/GmailApp helpers.
 */

interface EmailOptions {
  to: string;
  subject: string;
  body: string;
  htmlBody?: string;
  cc?: string;
  bcc?: string;
}

/**
 * Send a plain-text or HTML email via MailApp.
 * MailApp is quota-friendly for automated sends.
 */
function sendEmail(options: EmailOptions): void {
  MailApp.sendEmail({
    to: options.to,
    subject: options.subject,
    body: options.body,
    ...(options.htmlBody && { htmlBody: options.htmlBody }),
    ...(options.cc && { cc: options.cc }),
    ...(options.bcc && { bcc: options.bcc }),
  });
  Logger.log(`Email sent to ${options.to}: "${options.subject}"`);
}

/**
 * Get remaining daily MailApp quota.
 */
function getRemainingEmailQuota(): number {
  return MailApp.getRemainingDailyQuota();
}

/**
 * Send a simple notification to the script owner.
 */
function notifyOwner(subject: string, body: string): void {
  const owner = Session.getActiveUser().getEmail();
  sendEmail({ to: owner, subject, body });
}
