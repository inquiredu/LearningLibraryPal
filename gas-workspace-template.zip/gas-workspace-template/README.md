# GAS Workspace Template

A multi-container Google Apps Script monorepo with **clasp**, **TypeScript**, **ESLint**, and **Prettier** — optimized for GitHub Codespaces.

---

## Structure

```
gas-workspace-template/
├── packages/
│   ├── sheets/          # Sheets container (SpreadsheetApp)
│   ├── docs/            # Docs container (DocumentApp)
│   └── forms/           # Forms container (FormApp + MailApp + DriveApp)
├── shared/
│   ├── utils/           # Reusable GAS helpers (copy into packages before push)
│   └── types/           # Shared TypeScript types
├── .devcontainer/       # GitHub Codespaces config
├── .github/workflows/   # CI: lint + typecheck on PR
├── .env.example         # Credential template — copy to .env
├── tsconfig.json
├── .eslintrc.cjs
└── .prettierrc
```

---

## Quick Start

### 1. Use This Template

Click **"Use this template"** on GitHub to create your repo, then open in Codespaces.

The `postCreateCommand` will automatically run `npm install` and copy `.env.example` → `.env`.

### 2. Create Your Apps Script Projects

For each container, you need an existing Apps Script project with a Script ID.

- Go to [script.google.com](https://script.google.com)
- Create a new project bound to the appropriate Google file (Sheet, Doc, or Form)
- Copy the **Script ID** from: Project Settings → IDs

### 3. Configure Script IDs

**Option A — .env file** (recommended for Codespaces):
```bash
# Edit .env
SHEETS_SCRIPT_ID=your_script_id_here
DOCS_SCRIPT_ID=your_script_id_here
FORMS_SCRIPT_ID=your_script_id_here
```

Then update each `.clasp.json` with the corresponding ID:
```json
// packages/sheets/.clasp.json
{ "scriptId": "your_sheets_script_id_here" }
```

**Option B — Edit .clasp.json directly** (simpler for solo use):
Replace `REPLACE_WITH_*_SCRIPT_ID` in each `packages/*/.clasp.json`.

### 4. Authenticate with clasp

```bash
npm run login
```

This opens a browser OAuth flow. Your credentials are saved to `.clasprc.json` (gitignored).

> **Codespaces tip:** If the browser doesn't open, copy the URL from the terminal and open it manually.

### 5. Push to Google

```bash
# Push all containers
npm run push:all

# Push a specific container
npm run push:sheets
npm run push:docs
npm run push:forms
```

---

## Daily Workflow

| Command | Description |
|---|---|
| `npm run push:all` | Push all packages to Apps Script |
| `npm run pull:all` | Pull all packages from Apps Script |
| `npm run push:sheets` | Push only the Sheets container |
| `npm run lint` | Run ESLint across all packages |
| `npm run format` | Auto-format with Prettier |
| `npm run typecheck` | TypeScript type check (no emit) |
| `npm run build` | Compile TS (for validation only — GAS uses raw TS via clasp) |

---

## Working with Shared Utilities

GAS does not support npm imports at runtime. The `shared/` folder is a **copy-paste library**.

To use a shared utility in a package:

```bash
# Example: use drive.ts in the forms package
cp shared/utils/drive.ts packages/forms/src/drive.ts
```

Then reference it in your `packages/forms/.clasp.json` `filePushOrder` if order matters.

---

## Timezone

All `appsscript.json` files default to `America/Chicago` (Central Time). Update to match your deployment context.

---

## OAuth Scopes

Each container's `src/appsscript.json` declares its own scopes. Add/remove as needed:

| Scope | Service |
|---|---|
| `auth/spreadsheets` | Read/write Sheets |
| `auth/documents` | Read/write Docs |
| `auth/forms` | Read/write Forms |
| `auth/drive` | Full Drive access |
| `auth/drive.readonly` | Read-only Drive |
| `auth/gmail.send` | Send email via Gmail |
| `auth/script.container.ui` | Show menus/dialogs |

---

## Credential Security

| File | Committed? | Purpose |
|---|---|---|
| `.env` | ❌ No | Your Script IDs (local only) |
| `.clasprc.json` | ❌ No | clasp OAuth token (auto-generated) |
| `.env.example` | ✅ Yes | Template with placeholder values |
| `packages/*/.clasp.json` | ✅ Yes | Script ID per container (replace placeholders) |

---

## CI

GitHub Actions runs on every push and PR:
- ESLint
- TypeScript type check
- Prettier format check

No GAS credentials are needed in CI — it's lint/type only.
