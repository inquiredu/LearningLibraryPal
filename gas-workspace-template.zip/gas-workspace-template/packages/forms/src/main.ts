/**
 * packages/forms/src/main.ts
 * Entry point for the Forms container script.
 *
 * Trigger setup: In the Apps Script editor, add an onFormSubmit trigger
 * pointing to handleFormSubmit(), or use the installTrigger() function below.
 */

// ─── Trigger Handler ──────────────────────────────────────────────────────────

function handleFormSubmit(e: GoogleAppsScript.Events.FormsOnFormSubmit): void {
  const response = e.response;
  const itemResponses = response.getItemResponses();

  Logger.log(`New form submission at ${response.getTimestamp()}`);

  const summary: string[] = itemResponses.map(ir => {
    return `${ir.getItem().getTitle()}: ${ir.getResponse()}`;
  });

  Logger.log(summary.join('\n'));

  // Optional: send notification email
  // sendNotificationEmail(summary.join('\n'));
}

// ─── Form Utilities ───────────────────────────────────────────────────────────

function getFormSummary(): void {
  const form = FormApp.getActiveForm();
  const responses = form.getResponses();
  Logger.log(`Form: "${form.getTitle()}", Total responses: ${responses.length}`);
}

function installTrigger(): void {
  const form = FormApp.getActiveForm();

  // Remove existing to avoid duplicates
  ScriptApp.getProjectTriggers()
    .filter(t => t.getHandlerFunction() === 'handleFormSubmit')
    .forEach(t => ScriptApp.deleteTrigger(t));

  ScriptApp.newTrigger('handleFormSubmit')
    .forForm(form)
    .onFormSubmit()
    .create();

  Logger.log('onFormSubmit trigger installed.');
}

// ─── Mail ─────────────────────────────────────────────────────────────────────

function sendNotificationEmail(body: string): void {
  const recipient = Session.getActiveUser().getEmail();
  MailApp.sendEmail({
    to: recipient,
    subject: 'New Form Submission',
    body,
  });
}

// ─── Drive ────────────────────────────────────────────────────────────────────

function listRecentFiles(maxFiles = 10): void {
  const files = DriveApp.searchFiles(
    `modifiedDate > "${new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString()}"`
  );

  let count = 0;
  while (files.hasNext() && count < maxFiles) {
    const file = files.next();
    Logger.log(`${file.getName()} — ${file.getMimeType()}`);
    count++;
  }
}
