/**
 * packages/sheets/src/main.ts
 * Entry point for the Sheets container script.
 *
 * GAS NOTE: Functions must be top-level (not exported) to appear
 * as callable triggers in the Apps Script editor.
 */

// ─── Menu ────────────────────────────────────────────────────────────────────

function onOpen(e: GoogleAppsScript.Events.SheetsOnOpen): void {
  SpreadsheetApp.getUi()
    .createAddonMenu()
    .addItem('Run Sample', 'runSample')
    .addSeparator()
    .addItem('About', 'showAbout')
    .addToUi();
}

// ─── Triggers ─────────────────────────────────────────────────────────────────

function onEdit(e: GoogleAppsScript.Events.SheetsOnEdit): void {
  const range = e.range;
  Logger.log(`Cell edited: ${range.getA1Notation()} → ${e.value}`);
}

// ─── Sample Functions ─────────────────────────────────────────────────────────

function runSample(): void {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  const sheet = ss.getActiveSheet();
  const lastRow = sheet.getLastRow();

  Logger.log(`Sheet: "${sheet.getName()}", Last row: ${lastRow}`);

  // Write a timestamp to A1
  sheet.getRange('A1').setValue(`Last run: ${new Date().toISOString()}`);

  SpreadsheetApp.getUi().alert('Sample ran successfully. Check Logger for details.');
}

function showAbout(): void {
  SpreadsheetApp.getUi().alert('GAS Workspace Template — Sheets container');
}

// ─── Utilities ────────────────────────────────────────────────────────────────

function getSheetData(sheetName: string): unknown[][] {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  const sheet = ss.getSheetByName(sheetName);
  if (!sheet) throw new Error(`Sheet "${sheetName}" not found`);
  return sheet.getDataRange().getValues();
}
