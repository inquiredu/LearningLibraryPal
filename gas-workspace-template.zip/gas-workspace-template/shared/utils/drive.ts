/**
 * shared/utils/drive.ts
 * Reusable DriveApp helpers — copy into any package's src/ before pushing.
 *
 * GAS NOTE: clasp does not support cross-package imports at runtime.
 * Use these as copy-paste building blocks, or use clasp's `filePushOrder`
 * to push shared files alongside package files.
 */

/**
 * Get a file by ID, with a clear error if not found.
 */
function driveGetFile(fileId: string): GoogleAppsScript.Drive.File {
  const file = DriveApp.getFileById(fileId);
  if (!file) throw new Error(`Drive file not found: ${fileId}`);
  return file;
}

/**
 * Get a folder by ID, with a clear error if not found.
 */
function driveGetFolder(folderId: string): GoogleAppsScript.Drive.Folder {
  const folder = DriveApp.getFolderById(folderId);
  if (!folder) throw new Error(`Drive folder not found: ${folderId}`);
  return folder;
}

/**
 * List all files in a folder, returning name/id/mimeType.
 */
function driveListFiles(folderId: string): Array<{ name: string; id: string; mimeType: string }> {
  const folder = driveGetFolder(folderId);
  const files = folder.getFiles();
  const result: Array<{ name: string; id: string; mimeType: string }> = [];

  while (files.hasNext()) {
    const file = files.next();
    result.push({
      name: file.getName(),
      id: file.getId(),
      mimeType: file.getMimeType(),
    });
  }

  return result;
}

/**
 * Move a file to a different folder.
 */
function driveMoveFile(
  fileId: string,
  targetFolderId: string
): GoogleAppsScript.Drive.File {
  const file = driveGetFile(fileId);
  const targetFolder = driveGetFolder(targetFolderId);
  return file.moveTo(targetFolder);
}
