/**
 * packages/docs/src/main.ts
 * Entry point for the Docs container script.
 */

// ─── Menu ────────────────────────────────────────────────────────────────────

function onOpen(e: GoogleAppsScript.Events.DocsOnOpen): void {
  DocumentApp.getUi()
    .createAddonMenu()
    .addItem('Insert Timestamp', 'insertTimestamp')
    .addItem('Word Count', 'showWordCount')
    .addToUi();
}

// ─── Sample Functions ─────────────────────────────────────────────────────────

function insertTimestamp(): void {
  const doc = DocumentApp.getActiveDocument();
  const cursor = doc.getCursor();

  if (!cursor) {
    DocumentApp.getUi().alert('Place your cursor in the document first.');
    return;
  }

  const timestamp = new Date().toLocaleString('en-US', { timeZone: 'America/Chicago' });
  cursor.insertText(timestamp);
}

function showWordCount(): void {
  const doc = DocumentApp.getActiveDocument();
  const text = doc.getBody().getText();
  const wordCount = text.trim().split(/\s+/).filter(w => w.length > 0).length;
  DocumentApp.getUi().alert(`Word count: ${wordCount.toLocaleString()}`);
}

// ─── Utilities ────────────────────────────────────────────────────────────────

function getDocumentText(): string {
  return DocumentApp.getActiveDocument().getBody().getText();
}

function appendParagraph(text: string): GoogleAppsScript.Document.Paragraph {
  return DocumentApp.getActiveDocument().getBody().appendParagraph(text);
}
