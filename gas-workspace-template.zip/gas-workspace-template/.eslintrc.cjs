module.exports = {
  root: true,
  parser: '@typescript-eslint/parser',
  parserOptions: {
    ecmaVersion: 2019,
    sourceType: 'module',
  },
  plugins: ['@typescript-eslint'],
  extends: [
    'eslint:recommended',
    'plugin:@typescript-eslint/recommended',
  ],
  env: {
    es2019: true,
  },
  globals: {
    // GAS globals — these are injected at runtime, not imported
    SpreadsheetApp: 'readonly',
    DocumentApp: 'readonly',
    FormApp: 'readonly',
    DriveApp: 'readonly',
    MailApp: 'readonly',
    GmailApp: 'readonly',
    Logger: 'readonly',
    Session: 'readonly',
    Utilities: 'readonly',
    PropertiesService: 'readonly',
    ScriptApp: 'readonly',
    HtmlService: 'readonly',
    ContentService: 'readonly',
    UrlFetchApp: 'readonly',
    CacheService: 'readonly',
    LockService: 'readonly',
  },
  rules: {
    // GAS uses Logger, not console
    'no-console': 'warn',
    '@typescript-eslint/no-explicit-any': 'warn',
    '@typescript-eslint/explicit-function-return-type': 'off',
    '@typescript-eslint/no-unused-vars': ['error', { argsIgnorePattern: '^_' }],
    // GAS functions must be top-level (not exported) to be callable
    '@typescript-eslint/explicit-module-boundary-types': 'off',
  },
  ignorePatterns: ['dist/', 'node_modules/', '*.js'],
};
