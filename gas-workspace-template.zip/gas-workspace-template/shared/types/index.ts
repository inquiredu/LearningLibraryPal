/**
 * shared/types/index.ts
 * Common type definitions for the GAS workspace.
 */

/** Generic key-value pair from GAS PropertiesService */
export interface ScriptProperties {
  [key: string]: string;
}

/** Standard response shape for GAS web app doGet/doPost */
export interface WebAppResponse {
  status: 'ok' | 'error';
  message?: string;
  data?: unknown;
}

/** Result shape for Drive file listings */
export interface DriveFileInfo {
  name: string;
  id: string;
  mimeType: string;
}

/** Structured form response */
export interface FormResponseData {
  timestamp: Date;
  respondentEmail: string;
  answers: Record<string, string | string[]>;
}

/** Logger-friendly event envelope */
export interface AuditEntry {
  timestamp: string;
  user: string;
  action: string;
  detail?: string;
}
